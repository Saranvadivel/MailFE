import axios from 'axios';

const API_URL = `${window.location.origin}/api`;

// Register a new user
export const registerUser = async (email, password) => {
  try {
    return await axios.post(`${API_URL}/auth/register`, { email, password });
  } catch (error) {
    throw error; 
  }
};

// Log in a user and store JWT token
export const loginUser = async (email, password) => {
  try {
    const response = await axios.post(`${API_URL}/auth/login`, { email, password });
    localStorage.setItem('token', response.data.token); // Store JWT token in local storage
    return response;
  } catch (error) {
    throw error;
  }
};

// Send an email with optional attachment
export const sendEmail = async (emailData) => {
  const formData = new FormData();
  Object.keys(emailData).forEach((key) => formData.append(key, emailData[key]));

  try {
    return await axios.post(`${API_URL}/emails/send`, formData, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`, // Include token in the request headers
        'Content-Type': 'multipart/form-data',
      },
    });
  } catch (error) {
    throw error;
  }
};

// Fetch all emails (general emails endpoint)
export const getEmails = async () => {
  try {
    return await axios.get(`${API_URL}/emails`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
    });
  } catch (error) {
    throw error;
  }
};

// Fetch inbox-specific emails
export const getInboxEmails = async () => {
  try {
    return await axios.get(`${API_URL}/emails/inbox`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
    });
  } catch (error) {
    throw error;
  }
};

// Fetch sent emails
export const getSentEmails = async () => {
  try {
    return await axios.get(`${API_URL}/emails/sent`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
    });
  } catch (error) {
    throw error;
  }
};

// Log out the user by removing the token
export const logoutUser = () => {
  localStorage.removeItem('token');
};
