import React, { useEffect, useState } from 'react';
import { getSentEmails } from '../services/api'; // adjust the path based on your folder structure

const SentEmails = () => {
  const [sentEmails, setSentEmails] = useState([]);

  useEffect(() => {
    const fetchSentEmails = async () => {
      try {
        const response = await getSentEmails();
        setSentEmails(response.data); // Assuming response.data contains the emails array
      } catch (error) {
        console.error("Error fetching sent emails:", error);
      }
    };

    fetchSentEmails();
  }, []);

  return (
    <div>
      <h1>Sent Emails</h1>
      <ul>
        {sentEmails.map((email) => (
          <li key={email._id}>
            <strong>To:</strong> {email.to}<br />
            <strong>Subject:</strong> {email.subject}<br />
            <strong>Message:</strong> {email.message}<br />
            <strong>Sent At:</strong> {new Date(email.sentAt).toLocaleString()}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default SentEmails;
