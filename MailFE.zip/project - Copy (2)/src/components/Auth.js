import React, { useState } from 'react';
import { registerUser, loginUser } from '../services/api';

const Auth = ({ setUserEmail }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      await registerUser(email, password);
     
    } catch (err) {
      setError(err.message);
     
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await loginUser(email, password);
      setUserEmail(email); // Store the logged-in user's email
     
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div>
      <h2>Auth</h2>
      <form onSubmit={handleRegister}>
        <h3>Register</h3>
        <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        <button type="submit">Register</button>
      </form>
      <form onSubmit={handleLogin}>
        <h3>Login</h3>
        <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        <button type="submit">Login</button>
      </form>
      {error && <p>{error}</p>}
    </div>
  );
};

export default Auth;
