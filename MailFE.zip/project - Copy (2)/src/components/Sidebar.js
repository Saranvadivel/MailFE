// src/components/Sidebar.js
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Sidebar = ({ onLogout }) => {
  return (
    <div className="sidebar">
      <h3>Menu</h3>
      <ul>
        <li><Link to="/inbox">Inbox</Link></li>
        <li><Link to="/compose">Compose</Link></li>
        <li><Link to="/bin">Bin</Link></li>
        <li><Link to="/sent">Sent</Link></li>
        <li>
          <button onClick={onLogout}>Logout</button>
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;
