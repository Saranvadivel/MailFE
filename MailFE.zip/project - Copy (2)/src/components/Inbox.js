import React, { useEffect, useState } from 'react';
import { getInboxEmails } from '../services/api'; 

const Inbox = () => {
  const [inboxEmails, setInboxEmails] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchInboxEmails = async () => {
      try {
        const response = await getInboxEmails();
        setInboxEmails(response.data);
      } catch (err) {
        setError("Error fetching inbox emails: " + err.message);
      }
    };

    fetchInboxEmails();
  }, []);

  return (
    <div>
      <h2>Inbox</h2>
      {error && <p>{error}</p>}
      <ul>
        {inboxEmails.map((email) => (
          <li key={email._id}>
           
            <strong>To:</strong> {email.to} <br />
            <strong>Subject:</strong> {email.subject} <br />
            {email.cc && (
              <>
                <strong>CC:</strong> {email.cc.join(', ')} <br />
              </>
            )}
            {email.bcc && (
              <>
                <strong>BCC:</strong> {email.bcc.join(', ')} <br />
              </>
            )}
            <strong>Received At:</strong> {new Date(email.receivedAt).toLocaleString()} <br />
            <p>{email.message}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Inbox;
